export interface Osoba {
    id:number;
    imie:string;
    nazwisko:string;
    dataUr:string;
    zdjecie:string;
    wzrost:number;
    waga:number;
}
